# GeneanetForGramps - Selenium/lxml scraping, isolated in the worker process.
#
# This is the code that used to live directly in GBase/GPerson inside
# Gramps' own process. It now runs in a separate Python process (its own
# dedicated venv), so it never loads Selenium/lxml into Gramps' interpreter
# and a Chrome crash here cannot take Gramps down with it.
import base64
import json
import logging
import os
import random
import re
import socket
import tempfile
import time
from urllib.parse import urljoin, urlparse, parse_qs

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
from lxml import html
from lxml.etree import ParserError, XMLSyntaxError, XPathEvalError

from src.constants import ROOTURL
from src.credentials import get_credentials, CREDENTIALS_FILE
from src.date_utils import format_ca, convert_date, geneanet_strings
from src.exceptions import GeneanetAccessError

LOG = logging.getLogger("GeneanetForGramps.worker")

# Mutable module-level state: this worker process handles exactly one
# scraping session, so a plain global (mirroring the old state.selenium_driver
# singleton) is enough - no need for a class here.
_driver = None
_profile_dir = None
# Called with (code, **params) to tell whoever drives this worker what it is
# waiting for. Codes, not sentences: the worker cannot translate them.
_status_callback = None


def set_status_callback(callback):
    global _status_callback
    _status_callback = callback


def _status(code, **params):
    if _status_callback:
        _status_callback(code, **params)


def _free_tcp_port():
    """Ask the OS for a currently-unused local port, so each session gets
    its own remote-debugging port instead of a hardcoded one that can
    collide with other tools or a leftover process on the same port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def get_driver():
    global _driver, _profile_dir
    if _driver is None:
        options = Options()
        options.binary_location = "/usr/bin/chromium-browser"
        # A dedicated, throwaway profile directory per session, so a
        # leftover process from an earlier run can never hold a lock on
        # the profile a fresh session tries to start against.
        _profile_dir = tempfile.mkdtemp(prefix="geneanetforgramps-chrome-")
        options.add_argument("--user-data-dir=" + _profile_dir)
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=800,800")
        # An explicit --remote-debugging-port is required for the
        # chromedriver<->Chrome handshake to complete at all on some builds
        # (e.g. Ubuntu's snap-packaged chromium-browser, whose confinement
        # breaks the automatic port negotiation): without it,
        # webdriver.Chrome() hangs forever instead of raising. Picking a
        # fresh port per session (rather than a fixed one) avoids colliding
        # with other tools or an unrelated leftover process.
        options.add_argument("--remote-debugging-port=%d" % _free_tcp_port())
        # Hide automation indicators so Cloudflare allows manual checkbox clicks
        options.add_argument("--disable-blink-features=AutomationControlled")
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option("useAutomationExtension", False)
        _driver = webdriver.Chrome(options=options)
        # Remove the webdriver property from navigator to bypass Cloudflare detection
        _driver.execute_cdp_cmd(
            "Page.addScriptToEvaluateOnNewDocument",
            {"source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"},
        )
    return _driver


def close_driver():
    """Mirrors the previous state.close_selenium_driver(): always clears
    _driver even if quit() itself fails, then force-kills any leftover
    process still referencing our throwaway profile directory - some
    Chromium builds don't let chromedriver reliably track/kill the browser
    process it spawned, so quit() alone can leave a working window open."""
    global _driver, _profile_dir
    import shutil
    import subprocess
    if _driver is not None:
        try:
            _driver.quit()
        except Exception:
            LOG.debug("Failed to close the Selenium browser cleanly", exc_info=True)
        _driver = None
    if _profile_dir is not None:
        try:
            subprocess.run(["pkill", "-9", "-f", _profile_dir], check=False)
        except FileNotFoundError:
            LOG.debug("pkill is not available to force-close a leftover browser process")
        shutil.rmtree(_profile_dir, ignore_errors=True)
        _profile_dir = None


def _do_login(driver, purl):
    """Fill the Geneanet login form with stored credentials then navigate to purl."""
    username, password = get_credentials()
    if not username:
        LOG.warning(
            "No Geneanet credentials configured. In Gramps, open this tool's options "
            "and fill in 'Geneanet username (email)' and 'Geneanet password' under "
            "'Geneanet Login (optional)' - they are saved to %s.", CREDENTIALS_FILE)
        return False
    try:
        wait = WebDriverWait(driver, 10)
        # Geneanet (Symfony) uses _username/_password; fall back to type-based selectors
        user_field = None
        for sel in [(By.NAME, '_username'), (By.CSS_SELECTOR, 'input[type="email"]'), (By.NAME, 'email')]:
            try:
                user_field = wait.until(EC.presence_of_element_located(sel))
                break
            except TimeoutException:
                pass
        if user_field is None:
            LOG.warning('Could not locate the username field on the Geneanet login page.')
            return False
        user_field.clear()
        user_field.send_keys(username)
        pass_field = None
        for sel in [(By.NAME, '_password'), (By.CSS_SELECTOR, 'input[type="password"]')]:
            try:
                pass_field = driver.find_element(*sel)
                break
            except NoSuchElementException:
                pass
        if pass_field is None:
            LOG.warning('Could not locate the password field on the Geneanet login page.')
            return False
        pass_field.clear()
        pass_field.send_keys(password)
        pass_field.submit()
        # Wait until the browser leaves the login page
        WebDriverWait(driver, 15).until(
            lambda d: 'connexion' not in d.current_url and 'login' not in d.current_url
        )
        LOG.info("Login successful.")
        driver.get(purl)
        time.sleep(3)
        # Geneanet sometimes bounces straight to the homepage right after
        # login instead of honoring the page we just requested - detect
        # that and re-issue the request for the originally targeted page.
        retries = 0
        while urlparse(driver.current_url).path in ('', '/') and retries < 3:
            LOG.info("Redirected to the Geneanet homepage after login, retrying %s.", purl)
            time.sleep(2)
            driver.get(purl)
            time.sleep(3)
            retries += 1
        return True
    except Exception:
        # Auto-login is best-effort: any unexpected failure here must not
        # crash the worker, so this catch stays broad - but log it so the
        # reason is not lost.
        LOG.debug("Auto-login failed", exc_info=True)
        return False


# Leading words of the other one-line facts Geneanet prints in the same
# header block as the occupation (birth, baptism, death, burial...).
# Anything else in that block is the occupation.
_NON_OCCUPATION_PREFIXES = (
    "né", "née", "décédé", "décédée", "baptisé", "baptisée", "inhumé", "inhumée",
    "incinéré", "incinérée", "mort", "morte", "born", "deceased", "died",
    "baptized", "baptised", "christened", "buried", "cremated",
)


def _parse_occupation(tree):
    """The occupation is a plain <li> (no style attribute) in the list that
    follows the name/Sosa header, before the first section title ("Parents").
    Several lines are joined with "; "."""
    items = tree.xpath(
        '//div[@id="perso"]/div[@class="columns"]/h2[1]/preceding-sibling::ul/li[not(@style)]')
    lines = []
    for li in items:
        text = " ".join(li.text_content().split())
        if text and text.split()[0].lower().rstrip(".,:") not in _NON_OCCUPATION_PREFIXES:
            lines.append(text)
    return "; ".join(lines) or None


def tree_root_url(purl):
    """The home page of the tree a person page belongs to: same site and
    first path segment (the tree's name), without the person parameters."""
    parts = urlparse(purl)
    segments = [s for s in parts.path.split('/') if s]
    if not segments:
        return None
    lang = parse_qs(parts.query).get('lang', ['fr'])[0]
    return "%s://%s/%s?lang=%s" % (parts.scheme, parts.netloc, segments[0], lang)


def parse_tree_size(tree):
    """Number of persons of the tree, from the statistics block of its home
    page: a counter under the "individu" icon (the label next to it is
    translated, the icon class is not), which also links to the list of all
    the persons (m=LIST_IND). The number is formatted with thin spaces
    ("10 949"). None if the page has no such counter."""
    for xpath in (
            '//span[contains(@class,"svg-icon-individu-grey")]/span[contains(@class,"stats-number")]',
            '//a[contains(@href,"m=LIST_IND")]//span[contains(@class,"stats-number")]'):
        for element in tree.xpath(xpath):
            digits = re.sub(r'\D', '', element.text_content())
            if digits:
                return int(digits)
    return None


def fetch_tree_size(purl, timeout=120):
    """Total number of persons in the tree of purl, or None when it cannot be
    read. Never raises for a page problem: the size only sharpens the progress
    estimate, so the import goes on without it (the person pages have their
    own Cloudflare and login handling)."""
    root = tree_root_url(purl)
    if not root:
        return None
    driver = get_driver()
    driver.get(root)
    notice_shown = False
    elapsed = 0
    while elapsed < timeout:
        try:
            source = driver.page_source
            current_url = driver.current_url
        except WebDriverException:
            source, current_url = "", ""
        # "GeneanetKeys" is on every real Geneanet page; a Cloudflare
        # challenge page does not have it.
        if "GeneanetKeys" in source:
            try:
                return parse_tree_size(html.fromstring(source))
            except (ParserError, XMLSyntaxError):
                return None
        if 'connexion' in current_url or 'login' in current_url:
            return None
        if not notice_shown:
            LOG.warning("Cloudflare verification detected. Please complete the challenge in the browser window.")
            _status("cloudflare")
            notice_shown = True
        time.sleep(2)
        elapsed += 2
    return None


def parse_media(page_source):
    """The photos and documents attached to the person, as listed in the data
    the page embeds for its own scripts (the media block of the page is drawn
    by JavaScript from it, so it is not in the HTML itself):
    GeneanetKeys elements -> gntGeneweb -> media. [] when there are none."""
    decoder = json.JSONDecoder()
    for match in re.finditer(r'keys\.elements\s*,\s*', page_source):
        try:
            data, _end = decoder.raw_decode(page_source, match.end())
        except ValueError:
            continue
        media = (data.get("gntGeneweb") or {}).get("media") if isinstance(data, dict) else None
        if isinstance(media, list):
            return [entry for entry in media if isinstance(entry, dict)]
    return []


# Runs in the page: downloads a file with the session and cookies of the
# browser (so Cloudflare and the login are already handled) and hands it back
# as base64, which is the only way to get bytes out of Selenium.
_FETCH_JS = """
var url = arguments[0], done = arguments[arguments.length - 1];
fetch(url, {credentials: 'include'}).then(function(response) {
  if (!response.ok) { done({error: 'HTTP ' + response.status}); return; }
  var type = response.headers.get('Content-Type') || '';
  return response.blob().then(function(blob) {
    var reader = new FileReader();
    reader.onloadend = function() { done({type: type, data: String(reader.result).split(',')[1] || ''}); };
    reader.readAsDataURL(blob);
  });
}).catch(function(error) { done({error: String(error)}); });
"""

_EXTENSION_BY_TYPE = {
    "image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif",
    "image/webp": ".webp", "image/tiff": ".tif", "application/pdf": ".pdf",
}


def _media_url(entry):
    url = (entry.get("doc_images") or {}).get("original") or entry.get("doc_image") or ""
    return "https:" + url if url.startswith("//") else url


def _media_filename(entry, url, content_type):
    """<id>_<title><extension>. The id comes first and never changes: a file
    already downloaded by an earlier import is recognised by it."""
    extension = os.path.splitext(urlparse(url).path)[1].lower()
    if not re.fullmatch(r'\.[a-z0-9]{1,5}', extension):
        extension = _EXTENSION_BY_TYPE.get(content_type.split(';')[0].strip().lower(), ".jpg")
    title = re.sub(r'[^\w\- ]+', '', entry.get("doc_title") or "").strip()[:60].replace(' ', '_')
    return "%s_%s%s" % (_media_key(entry), title or "media", extension)


def _media_key(entry):
    return str(entry.get("doc_part_id") or entry.get("doc_id") or entry.get("id"))


def download_media(driver, entries, media_dir):
    """Download the files of `entries` into media_dir. Returns the list of
    what was obtained ({title, date, file, is_default}) and a list of
    messages for what could not be. A file that is already there is reused."""
    os.makedirs(media_dir, exist_ok=True)
    driver.set_script_timeout(60)
    obtained, errors = [], []
    for index, entry in enumerate(entries, 1):
        title = entry.get("doc_title") or ""
        url = _media_url(entry)
        if not url:
            errors.append("%s (no address)" % (title or _media_key(entry)))
            continue
        _status("media", index=index, total=len(entries))
        try:
            key = _media_key(entry) + "_"
            present = sorted(f for f in os.listdir(media_dir) if f.startswith(key))
            if present:
                path = os.path.join(media_dir, present[0])
            else:
                result = driver.execute_async_script(_FETCH_JS, url)
                if not result or result.get("error"):
                    raise RuntimeError((result or {}).get("error") or "no answer")
                content = base64.b64decode(result.get("data") or "")
                if not content:
                    raise RuntimeError("empty file")
                path = os.path.join(media_dir, _media_filename(entry, url, result.get("type") or ""))
                with open(path + ".part", "wb") as f:
                    f.write(content)
                os.replace(path + ".part", path)
                time.sleep(1)  # be fair with the site between two files
            obtained.append({"title": title, "date": entry.get("doc_date"), "file": path,
                             "is_default": bool(entry.get("is_default"))})
        except (WebDriverException, RuntimeError, OSError, ValueError) as err:
            LOG.warning("Could not download %s: %s", url, err)
            errors.append("%s (%s)" % (title or url, err))
    return obtained, errors


def _is_profile_link(a):
    """True if this <a> can lead to another person's page. Footnote anchors
    next to a union (e.g. href="#note-wed-1", the marriage note) are also
    <a> tags without an image: taken for the spouse's link, they overwrote
    the real one and resolved to the site root plus a fragment, a page the
    scraper then waited on until Cloudflare-timeout."""
    href = a.xpath('attribute::href')
    if not href:
        return False
    href = str(href[0]).strip()
    return bool(href) and not href.startswith(('#', 'javascript:', 'mailto:'))


def scrape_person(purl, media_dir=None):
    """Fetch and parse a Geneanet person page. Returns a plain dict of the
    fields the caller previously found on GPerson.g_* / spouseref / fref /
    mref / etc after from_geneanet(). Raises GeneanetAccessError for an
    unrecoverable access failure (Cloudflare timeout, failed login) and lets
    any other exception propagate as-is - the caller decides what to do
    with it (this mirrors the previous state.stop_on_error handling, which
    now lives on the Gramps side)."""
    LOG.info("Page considered: %s", purl)
    driver = get_driver()

    # Wait for the real page content to appear, tolerating a Cloudflare
    # challenge that can be shown more than once (e.g. a second checkbox
    # click) and a login/CAPTCHA redirect happening in between. Poll for
    # the actual target element instead of trusting the page title, which
    # is also localized (French on this site) and unreliable to match
    # reliably against a fixed set of English substrings.
    #
    # Some other, unrelated redirect page can also leave the browser stuck
    # (neither the person page, nor a recognizable Cloudflare/login page) -
    # observed ending an import outright. Rather than waiting on that one
    # navigation forever, the wait is split into bounded attempts that each
    # re-issue the request from scratch: a transient redirect quietly heals
    # itself on the next try instead of hard-failing the whole import.
    max_attempts = 3
    per_attempt_timeout = 60
    poll_interval = 2
    notice_shown = False
    login_attempted = False
    found = False
    for attempt in range(1, max_attempts + 1):
        if attempt > 1:
            _status("retry", attempt=attempt, max=max_attempts)
        driver.get(purl)
        elapsed = 0
        while elapsed < per_attempt_timeout:
            try:
                found = bool(driver.find_elements(By.ID, "person-title"))
                current_url = driver.current_url
            except WebDriverException:
                found, current_url = False, ""

            if found:
                break

            if ('connexion' in current_url or 'login' in current_url) and not login_attempted:
                login_attempted = True
                LOG.info("Geneanet login required for %s.", purl)
                _status("login")
                if not _do_login(driver, purl):
                    raise GeneanetAccessError(
                        "Geneanet requires logging in to view %s, and auto-login could not "
                        "complete it (no credentials configured, or login failed/blocked by "
                        "a CAPTCHA). Open this tool's options and fill in 'Geneanet username "
                        "(email)' and 'Geneanet password' under 'Geneanet Login (optional)', "
                        "then try again." % purl,
                        code="login_failed", url=purl)
                continue

            if not notice_shown:
                LOG.warning("Cloudflare verification detected. Please complete the challenge in the browser window.")
                _status("cloudflare")
                notice_shown = True

            time.sleep(poll_interval)
            elapsed += poll_interval

        if found:
            break

        LOG.warning(
            "The page for %s did not resolve to a person page within %ds "
            "(attempt %d/%d, ended up on %s) - retrying with a fresh request.",
            purl, per_attempt_timeout, attempt, max_attempts, driver.current_url)

    if not found:
        raise GeneanetAccessError(
            "The page for %s never resolved to a person page after %d attempts "
            "(Cloudflare check likely still pending, or the site kept redirecting "
            "elsewhere)." % (purl, max_attempts),
            code="page_unresolved", url=purl, attempts=max_attempts)

    LOG.debug("URL: %s", driver.current_url)
    LOG.debug("Title: %s", driver.title)

    page_content = driver.page_source
    with open("/tmp/geneanet-selenium.html", "w", encoding="utf-8") as f:
        f.write(page_content)

    try:
        tree = html.fromstring(page_content)
    except (ParserError, XMLSyntaxError):
        LOG.error("Unable to perform HTML analysis")
        raise

    # The page's language is set by its own "lang=" URL parameter,
    # independent from whatever locale the caller (Gramps) runs in.
    page_lang = parse_qs(urlparse(purl).query).get('lang', ['fr'])[0]
    strings = geneanet_strings(page_lang)

    # Wait after a Geneanet request to be fair with the site
    # between 2 and 7 seconds
    _status("pause")
    time.sleep(random.randint(2, 7))

    data = {
        'url': purl,
        'g_sex': 'U',
        'g_firstname': "",
        'g_lastname': "",
        'g_birthdate': None,
        'g_birthplace': None,
        'g_birthplacecode': None,
        'g_deathdate': None,
        'g_deathplace': None,
        'g_deathplacecode': None,
        'occupation': None,
        'media': [],
        'media_errors': [],
        'spouseref': [],
        'marriagedate': [],
        'marriageplace': [],
        'marriageplacecode': [],
        'childref': [],
        'fref': "",
        'mref': "",
    }

    try:
        # Should return M or F
        sex = tree.xpath('//div[@id="person-title"]//img/attribute::alt')
        data['g_sex'] = sex[0]
        # Seems we have a french codification on the site
        if sex[0][0] == 'H':
            data['g_sex'] = 'M'
        elif sex[0][0] == 'F':
            data['g_sex'] = 'F'
    except IndexError:
        data['g_sex'] = 'U'
    try:
        name = tree.xpath('//span[@class="gw-individual-info-name-firstname"]//a/text()')
        data['g_firstname'] = " ".join(str(name[0]).split()).title()

        if data['g_firstname'] == "":
            LOG.warning("Name not detected, html has changed")

        name = tree.xpath('//span[@class="gw-individual-info-name-lastname"]//a/text()')
        data['g_lastname'] = " ".join(str(name[0]).split()).title()
    except IndexError:
        LOG.warning("Name not detected")
        data['g_firstname'] = ""
        data['g_lastname'] = ""
    LOG.info("==> GENEANET Name: %s %s", data['g_firstname'], data['g_lastname'])
    LOG.debug("Sex: %s", data['g_sex'])
    try:
        sstring = '//li[contains(., "' + strings['born'] + '")]/text()'
        LOG.debug("sstring: %s", sstring)
        birth = tree.xpath(sstring)
    except XPathEvalError:
        birth = [""]
    LOG.debug("birth: %s", birth)
    try:
        sstring = '//li[contains(., "' + strings['deceased'] + '")]/text()'
        LOG.debug("sstring: %s", sstring)
        death = tree.xpath(sstring)
    except XPathEvalError:
        death = [""]
    LOG.debug("death: %s", death)
    try:
        # sometime parents are using circle, sometimes disc !
        parents = tree.xpath(
            '//ul[not(descendant-or-self::*[@class="fiche_union"])]//li[@style="vertical-align:middle;list-style-type:disc" or @style="vertical-align:middle;list-style-type:circle"]')
    except XPathEvalError:
        parents = []
    try:
        spouses = tree.xpath('//ul[@class="fiche_union"]/li')
    except XPathEvalError:
        spouses = []
    try:
        ld = convert_date(birth[0].split('-')[0].split()[1:], page_lang)
        LOG.debug("Birth: %s", ld)
        data['g_birthdate'] = format_ca(ld, page_lang)
    except (IndexError, ValueError, AttributeError):
        LOG.debug("Error in birth date process", exc_info=True)
        data['g_birthdate'] = None
    try:
        data['g_birthplace'] = str(
            ' '.join(birth[0].split('-')[1:]).split(',')[0].strip()).title()
        LOG.debug("Birth place: %s", data['g_birthplace'])
    except (IndexError, AttributeError):
        data['g_birthplace'] = None
    try:
        g_birthplacecode = str(' '.join(birth[0].split('-')[1:]).split(',')[1]).strip()
        match = re.search(r'\d\d\d\d\d', g_birthplacecode)
        if not match:
            data['g_birthplacecode'] = None
        else:
            LOG.debug("Birth place code: %s", g_birthplacecode)
            data['g_birthplacecode'] = g_birthplacecode
    except (IndexError, AttributeError):
        data['g_birthplacecode'] = None
    try:
        ld = convert_date(death[0].split('-')[0].split()[1:], page_lang)
        LOG.debug("Death: %s", ld)
        data['g_deathdate'] = format_ca(ld, page_lang)
    except (IndexError, ValueError, AttributeError):
        data['g_deathdate'] = None
    try:
        data['g_deathplace'] = str(
            ' '.join(death[0].split('-')[1:]).split(',')[0]).strip().title()
        LOG.debug("Death place: %s", data['g_deathplace'])
    except (IndexError, AttributeError):
        data['g_deathplace'] = None
    try:
        g_deathplacecode = str(' '.join(death[0].split('-')[1:]).split(',')[1]).strip()
        match = re.search(r'\d\d\d\d\d', g_deathplacecode)
        if not match:
            data['g_deathplacecode'] = None
        else:
            LOG.debug("Death place code: %s", g_deathplacecode)
            data['g_deathplacecode'] = g_deathplacecode
    except (IndexError, AttributeError):
        data['g_deathplacecode'] = None

    data['occupation'] = _parse_occupation(tree)
    LOG.debug("Occupation: %s", data['occupation'])

    s = 0
    sname = []
    sref = []
    marriage = []
    for spouse in spouses:
        # Pre-fill a slot for this spouse before looking for its <a> tag: a
        # fully private/hidden spouse has none at all, and without this,
        # sname[s]/sref[s] below would index past the end of the list and
        # crash.
        sname.append("")
        sref.append("")
        for a in spouse.xpath('a'):
            if not _is_profile_link(a):
                continue
            sosa = a.find('img')
            if sosa is None:
                try:
                    sname[s] = str(a.xpath('text()')[0]).title()
                    LOG.debug("Spouse name: %s", sname[s])
                except IndexError:
                    sname[s] = ""
                try:
                    sref[s] = str(a.xpath('attribute::href')[0])
                    LOG.debug("Spouse ref: %s", urljoin(ROOTURL, sref[s]))
                except IndexError:
                    sref[s] = ""

        # An empty href means Geneanet shows this spouse without a
        # clickable profile (private/hidden individual) - keep an empty
        # ref rather than fabricating a link to the site root.
        data['spouseref'].append(urljoin(ROOTURL, sref[s]) if sref[s] else "")

        try:
            marriage.append(str(spouse.xpath('em/text()')[0]))
        except IndexError:
            marriage.append(None)
        try:
            ld = convert_date(marriage[s].split(',')[0].split()[1:], page_lang)
            LOG.debug("Married: %s", ld)
            data['marriagedate'].append(format_ca(ld, page_lang))
        except (AttributeError, IndexError, ValueError):
            data['marriagedate'].append(None)
        try:
            data['marriageplace'].append(str(marriage[s].split(',')[1][1:]).title())
            LOG.debug("Married place: %s", data['marriageplace'][s])
        except (AttributeError, IndexError):
            data['marriageplace'].append(None)
        try:
            marriageplacecode = str(marriage[s].split(',')[2][1:])
            match = re.search(r'\d\d\d\d\d', marriageplacecode)
            if not match:
                data['marriageplacecode'].append(None)
            else:
                LOG.debug("Married place code: %s", marriageplacecode)
                data['marriageplacecode'].append(marriageplacecode)
        except (AttributeError, IndexError):
            data['marriageplacecode'].append(None)

        cnum = 0
        clist = []
        for c in spouse.xpath('ul/li'):
            # Reset for each child - a private/hidden child has no <a> at
            # all, and must not silently reuse the previous child's
            # name/ref (or leave cref undefined on the very first child of
            # the union).
            cname, cref = "", None
            for a in c.xpath('a'):
                if not _is_profile_link(a):
                    continue
                sosa = a.find('img')
                if sosa is None:
                    try:
                        cname = c.xpath('a/text()')[0].title()
                        LOG.debug("Child %d name: %s", cnum, cname)
                    except IndexError:
                        cname = ""
                    try:
                        cref = urljoin(ROOTURL, str(a.xpath('attribute::href')[0]))
                        LOG.debug("Child %d ref: %s", cnum, cref)
                    except IndexError:
                        cref = None

            clist.append(cref)
            cnum = cnum + 1
        data['childref'].append(clist)
        s = s + 1
        # End spouse loop

    prefl = []
    for p in parents:
        LOG.debug("%s", p.xpath('text()'))
        texts = p.xpath('text()')
        if texts and texts[0] == '\n':
            # Reset for each parent entry - a private/hidden parent has no
            # <a> at all, and must not silently reuse the previous parent's
            # name/ref.
            pname, pref = "", ""
            for a in p.xpath('a'):
                if not _is_profile_link(a):
                    continue
                sosa = a.find('img')
                if sosa is None:
                    try:
                        pname = a.xpath('text()')[0].title()
                    except IndexError:
                        pname = ""
                    try:
                        pref = a.xpath('attribute::href')[0]
                    except IndexError:
                        pref = ""
                    # only consider first valid link instead of overwriting with eg "seigneur de XYZ" or "propriétaire à XYZ":
                    if pname and pref:
                        break

            if pref:
                ref = urljoin(ROOTURL, str(pref))
                LOG.info("Parent name: %s (%s)", pname, ref)
                prefl.append(ref)
            else:
                # Geneanet shows this parent without a clickable profile
                # (private/hidden individual) - keep the slot empty rather
                # than fabricating a link to the site root.
                LOG.info("Parent has no navigable link (private profile)")
                prefl.append("")
    try:
        data['fref'] = prefl[0]
    except IndexError:
        data['fref'] = ""
    try:
        data['mref'] = prefl[1]
    except IndexError:
        data['mref'] = ""

    if media_dir:
        data['media'], data['media_errors'] = download_media(
            driver, parse_media(page_content), media_dir)

    return data
