# GeneanetForGramps - Top-level import orchestration
import sys

import src.state as state
from src.state import _, LOG
from src.gperson import GPerson
from src.progress import ImportProgress
from src import report
from src.exceptions import GeneanetAccessError, ImportCancelled
from src.worker_env import WorkerEnvError
from gramps.gui.dialog import ErrorDialog, InfoDialog


def _report_conflict(title, detail):
    """Report a blocking conflict: stop the CLI, or show a popup in GUI mode."""
    LOG.error(detail)
    report.current.conflict("%s: %s" % (title, detail.replace("\n", " / ")))
    if not state.GUIMODE:
        state.db.close()
        sys.exit(_("Do not continue without force"))
    else:
        ErrorDialog(title, detail + "\n\n" + _("Please fix the person in Gramps, or enable Force Import to overwrite it."))


def _dates_conflict(gramps_date, geneanet_date):
    """A conflict only exists when BOTH sides have a value and they differ.
    An empty value on either side is not a conflict: it is simply filled in
    from Geneanet (or left as-is in Gramps) by the smart-copy logic."""
    if not gramps_date or not geneanet_date:
        return False
    return gramps_date != geneanet_date


def geneanet_to_gramps(p, level, gid, url):
    # Every person fetched during the (possibly deep) recursive import goes
    # through here first, so this is the one place that needs to check for
    # a user-requested Stop - raising unwinds the whole recursion instead of
    # fetching and reporting a conflict for every remaining person.
    if state.progress.cancelled():
        raise ImportCancelled()

    if not p:
        p = GPerson(level)
    state.progress.page_started(url, level)
    p.from_geneanet(url)
    state.progress.page_done(p, level, url)
    p.from_gramps(gid)

    if gid is not None:
        if (p.firstname != p.g_firstname or p.lastname != p.g_lastname) and not state.force:
            detail = (_("Gramps   person: %s %s") % (p.firstname, p.lastname) + "\n" +
                      _("Geneanet person: %s %s") % (p.g_firstname, p.g_lastname))
            _report_conflict(_("Geneanet import: name conflict"), detail)
            return None

        # Fix potential empty dates
        if p.g_birthdate == "":
            p.g_birthdate = None
        if p.birthdate == "":
            p.birthdate = None
        if p.g_deathdate == "":
            p.g_deathdate = None
        if p.deathdate == "":
            p.deathdate = None

        birth_conflict = _dates_conflict(p.birthdate, p.g_birthdate)
        death_conflict = _dates_conflict(p.deathdate, p.g_deathdate)

        if (birth_conflict or death_conflict) and not state.force:
            detail = (_("Gramps   person birth/death: %s / %s") % (p.birthdate, p.deathdate) + "\n" +
                      _("Geneanet person birth/death: %s / %s") % (p.g_birthdate, p.g_deathdate))
            _report_conflict(_("Geneanet import: birth/death conflict"), detail)
            return None

    p.to_gramps()
    report.current.person_done(p.gid, p.created)
    return p


def _show_summary(pages, seconds):
    """Tell the user what the import did, in a window that stays until it is
    closed (GUI) or as plain output (command line)."""
    text = report.current.render(pages, seconds)
    if state.GUIMODE:
        InfoDialog(report.current.title(), text)
    else:
        print("\n" + report.current.title() + "\n" + text)


def _read_tree_size(purl):
    """Total number of persons of the tree being imported from, used to
    bound the progress estimate. None when unavailable: that never stops
    the import, except when the scraper environment itself cannot be set
    up, which is reported now rather than as a failure on every page."""
    state.progress.set_status(_("Reading the size of the Geneanet tree..."))
    try:
        return state.get_worker_client().tree_size(purl)
    except (GeneanetAccessError, ImportCancelled):
        raise
    except WorkerEnvError as err:
        raise GeneanetAccessError(str(err)) from err
    except Exception:
        LOG.debug("Could not read the tree size", exc_info=True)
        return None


def g2gaction(gid, purl):
    if state.progress is None:
        state.progress = ImportProgress()
    report.start().media_enabled = state.media
    try:
        try:
            state.progress.set_tree_size(_read_tree_size(purl))
            gp = geneanet_to_gramps(None, 0, gid, purl)

            if gp is not None:
                if state.ascendants:
                    gp.recurse_parents(0)

                fam = []
                if state.spouses:
                    fam = gp.add_spouses(0)
                else:
                    # TODO: If we don't ask for spouses, we won't get children at all
                    pass

                if state.descendants:
                    for f in fam:
                        f.recurse_children(0)
        except GeneanetAccessError as e:
            detail = str(e)
            report.current.finish(report.STOPPED, detail)
            LOG.error(detail)
            if state.GUIMODE:
                ErrorDialog(_("Geneanet import stopped"), detail)
            else:
                LOG.error(_("Geneanet import stopped."))
        except ImportCancelled:
            report.current.finish(report.CANCELLED)
            LOG.info(_("Geneanet import cancelled by the user."))
    finally:
        state.close_worker()
        pages, seconds = state.progress.estimator.done, state.progress.elapsed()
        state.progress.close()
        state.progress = None
        _show_summary(pages, seconds)
